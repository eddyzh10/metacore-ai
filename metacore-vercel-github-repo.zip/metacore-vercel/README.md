# MetaCore Vercel Frontend

Vercel-ready React UI for MetaCore.
