
import React from 'react'
import ReactDOM from 'react-dom/client'
import MetaCoreHub from './MetaCoreHub'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <MetaCoreHub />
  </React.StrictMode>
)
